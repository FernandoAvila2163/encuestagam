<!DOCTYPE html>
<html>
<head>
<title>Entrar!!!</title> 
<link rel="icon" type="image/x-icon" href="imagenes/gam.ico"> 
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}


input[type=text], input[type=password] {
  width: center;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 5px solid #ccc;
  box-sizing: border-box;
  border-radius: 2px;
  background-color: #E5E7E9;
}

button {
  color: black;
  padding: 12px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: center;
}

button:hover {
  opacity: 0.8;
  background-color: #58D68D ;
}


.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;

}

img.avatar {
  width: 12%;
  border-radius: 10%;
}

.container {
  margin: 30px;
  padding: 30px;
  /* IMPORTANTE */
  text-align: center;
  align-items: center;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
}
</style>
</head>
<body style="background-color: #AED6F1 ">
<form action="graficos.php" method="post">
    <div class="imgcontainer">
    <img src="imagenes/gam.ico" alt="Avatar" class="avatar">
  </div>
  <div class="container">
    <label for="uname"><b>Usuario:</b></label><br>
    <input type="text" placeholder="Nombre de Usuario" name="u" required><br>

    <label for="psw"><b>Contraseña:</b></label><br>
    <input type="password" placeholder="Contraseña" name="p" required><br><br>
    <button type="submit"><b>Entrar</b></button>
  </div>
    <footer align="center">
      <div class="container text-center" align="center">
        <span>Software GAM <sup>©</sup> Todos los Derechos Reservados.</span>
      </div>
    </footer>
</form>

</body>
</html>