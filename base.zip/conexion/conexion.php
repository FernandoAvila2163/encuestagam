<?php 
$conexion = mysqli_connect('localhost', 'gamse627_encgam', '8J8TiNJLPZmh', 'gamse627_encuestagam');
 ?>