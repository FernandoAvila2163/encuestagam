<?php
  include ('../conexion/conexion.php'); 
  $fecha = $_POST['dia3'];
  $fecha2 = $_POST['dia4'];
  if (!isset($_POST['dia3'])) {
    header('Location: graficos.php');
  }
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../css/hoja_graficos.css">
  <link rel="icon" type="image/x-icon" href="../imagenes/gam.ico">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- 	aqui van las librerias necesarias para los graficos-->
  	 <script src="https://code.highcharts.com/highcharts.js"></script>
  	 <script src="https://code.highcharts.com/modules/exporting.js"></script>
  	 <script src="https://code.highcharts.com/modules/export-data.js"></script>
  	 <script src="https://code.highcharts.com/modules/accessibility.js"></script>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 	 <script src="https://cdn.jsdelivr.net/npm/promise-polyfill@8/dist/polyfill.js"></script>
   <script src="https://code.highcharts.com/modules/variable-pie.js"></script>

 
	<title>Graficos Inducción</title>
</head>
<body style="background: linear-gradient(to bottom, rgba(166, 218, 231, 0.49), white);">


<!--   Validacion de resultados-->
<?php
     $registro="SELECT COUNT(P1) FROM induccion WHERE fecha BETWEEN '$fecha' AND '$fecha2'";
     $resultado=mysqli_query($conexion,$registro);
     while($mos=mysqli_fetch_array($resultado)){
     if ($mos['COUNT(P1)'] == 0) {
 echo'<script type="text/javascript">
    alert("NO HAY RESULTADOS ENTRE LAS FECHAS SELECCIONADAS");
    window.history.back();
    </script>';
    exit;
}}
     ?>
<input class="botonGraficos" type="button" name="" id="juntas" value="Regresar"  onclick=" window.history.back();">
<label style="align-content: center;" >Respuestas del <?php echo "$fecha al $fecha2" ; ?></label>


<!-- ESTE DIV MUESTRA LOS RESULTADOS DE LA PREGUNTA 1-->
 <div class="padre" id="1" >
 <strong><h2>¿La información previa que se te brindo acerca del curso de inducción (horarios, contenido y objetivos) fue clara y oportuna?</h2></strong> 
  <figure class="highcharts-figure">
    <div id="P1"></div>
    </figure>
    </div>




<!-- Matriz-->

    <div class="padre" id="2" >
   <span>
        <h2> Preguntas: Considerando que 1 es la mínima y 5 la máxima en puntuación </h2>
    </span>

       <figure class="highcharts">
    <div id="Imatriz"></div>
    </figure>
    </div>



<!-- ESTE DIV MUESTRA LOS RESULTADOS DE LA PREGUNTA 3-->

 <div class="padre" id="3" >
  <span><h2>
    ¿El curso ha aumentado mi interés en la carrera como Asesor Profesional en Seguros (APS)?</h2>
  </span>
    <figure class="highcharts-figure">
    <div id="P3"></div>
    </figure>
    <span>
       <h2>¿Por qué?</h2> 
    </span>
      <table border="1" id="" align="center" >
        <tr>
            <td>
                <H3>
    <!--     CONSULTA QUE MUSTRA LA CANTIDAD DE RESPUESTAS -->
                 Respuestas <?php
     $numero="SELECT COUNT(P3P) FROM induccion where P3P != '' AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(P3P)'];}
     ?>         
                </H3> 
            </td>       
        </tr>
    <!-- CONSULTA QUE MUESTRA LAS RESPUESTAS -->        
        <?php 
        $sql="SELECT P3P from induccion where P3P != '' AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $result=mysqli_query($conexion,$sql);

        while($mostrar=mysqli_fetch_array($result)){
         ?>
            <td><?php echo $mostrar['P3P'] ?></td>
        </tr>
    <?php 
    }
     ?>
     </table>
    </div>



<!-- ESTE DIV MUESTRA LOS RESULTADOS DE LA PREGUNTA 4-->

 

  <div class="padre" id="5" >
    <span>
        <h2> ¿Le recomendarías los temas abordados en la reunión a tus colegas?</h2>
    </span>

 <figure class="grafico2">
    <div id="P4"></div>
 </figure>
    <br>
    <span>
       <h2>¿Por qué?</h2> 
    </span>
      <table border="1" id="" align="center" >
        <tr>
            <td>
                <H3>
    <!--     CONSULTA QUE MUSTRA LA CANTIDAD DE RESPUESTAS -->
                 Respuestas <?php
     $numero="SELECT COUNT(P4P) FROM induccion where P4P != '' AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(P4P)'];}
     ?>         
                </H3> 
            </td>       
        </tr>
    <!-- CONSULTA QUE MUESTRA LAS RESPUESTAS -->        
        <?php 
        $sql="SELECT P4P from induccion where P4P != '' AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $result=mysqli_query($conexion,$sql);

        while($mostrar=mysqli_fetch_array($result)){
         ?>
            <td><?php echo $mostrar['P4P'] ?></td>
        </tr>
    <?php 
    }
     ?>
     </table>
    </div>




<!-- ESTE DIV MUESTRA LOS RESULTADOS DE LA PREGUNTA 5-->

    <div class="padre" id="cinco" >
    <span>
   <h2> ¿Consideras que con las herramientas y conocimientos adquiridos estas preparado(a) para realizar tu primer venta?
   </h2>
    </span>
     <figure class="highcharts-figure">
    <div id="P5"></div>
    </figure>

   <br>
   <span>
     <h2>¿Por qué?</h2> 
      <table border="1" id="" align="center" >
        <tr>
            <td>
                <H3>
    <!--     CONSULTA QUE MUSTRA LA CANTIDAD DE RESPUESTAS -->
                 Respuestas <?php
     $numero="SELECT COUNT(P5P) FROM induccion where P5P != '' AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(P5P)'];}
     ?>         
                </H3> 
            </td>       
        </tr>
    <!-- CONSULTA QUE MUESTRA LAS RESPUESTAS -->        
        <?php 
        $sql="SELECT P5P from induccion where P5P != '' AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $result=mysqli_query($conexion,$sql);

        while($mostrar=mysqli_fetch_array($result)){
         ?>
            <td><?php echo $mostrar['P5P'] ?></td>
        </tr>
    <?php 
    }
     ?>
     </table>
   </span>
    </div>






<!-- ESTE DIV MUESTRA LOS RESULTADOS DE LA PREGUNTA 7-->


    <div class="padre" id="siete" >
    <span>
    <h2>¿Hay algo que se podría mejorar en las reuniones semanales? Por favor, déjanos saber tu opinión:</h2> 
    </span>
     <table border="1" id="" align="center" >
        <tr>
            <td>
                <H3>
      <!--     CONSULTA QUE MUSTRA LA CANTIDAD DE RESPUESTAS --> 
                Respuestas <?php
     $numero="SELECT COUNT(P6) FROM induccion where P6 != '' AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(P6)'];}
     ?>         
                </H3> 
            </td>       
        </tr>
       <!-- CONSULTA QUE MUESTRA LAS RESPUESTAS -->
        <?php 
        $sql="SELECT P6 from induccion where P6 != '' AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $result=mysqli_query($conexion,$sql);

        while($mostrar=mysqli_fetch_array($result)){
         ?>
            <td><?php echo $mostrar['P6'] ?></td>
        </tr>
    <?php 
    }
     ?>
     </table>
    </div>

 
<!--  EN ESTE DIV MUESTRA LOS RESULTADOS DE LAS ESTRELLAS -->
 <div class="padre" id="ocho" >
  <span>
 <h2>En general, ¿Cómo evalúas las juntas semanales que brindamos en GAM?</h2> 
  </span>
  
   <figure class="highcharts-figure">
    <div id="estrellas"></div>
 </figure>

 </div>


</body>
</html>







<!-- inician las funciones de javascript -->
  <script type="text/javascript">


/* ==========================
GRAFICO RESPUESTAS P1 TABLA INDUCCION
============================= */
Highcharts.chart('P1', {
    chart: {
        type: 'column'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: [
            'Respuestas',
            'En total desacuerdo',
            'En desacuerdo',
            'Neutral',
            'De acuerdo',
            'Totalmente de acuerdo'
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: ''
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'En total desacuerdo',
        data: [<?php

   $prueba="SELECT count(P1) FROM induccion where P1 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P1)']; }
    ?>,]
    }, {
        name: 'En desacuerdo',
        data: [<?php

   $prueba="SELECT count(P1) FROM induccion where P1 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P1)']; }


    ?>]
    }, {
        name: 'Neutral',
        data: [<?php

   $prueba="SELECT count(P1) FROM induccion where P1 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P1)']; }


    ?>] 
    }, {
        name: 'De acuerdo',
        data: [<?php

   $prueba="SELECT count(P1) FROM induccion where P1 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P1)']; }


    ?>]
    }, {
        name: 'En total acuerdo',
        data: [<?php

   $prueba="SELECT count(P1) FROM induccion where P1 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P1)']; }


    ?>]
    }]
    });


/* ==========================
        GRAFICO MATRIZ
============================= */

Highcharts.chart('Imatriz', {
    chart: {
        type: 'column'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: [
            'Pregunta:1',
            'Pregunta:2',
            'Pregunta:3',
            'Pregunta:4',
            'Pregunta:5',
            'Pregunta:6',
            'Pregunta:7',
            'Pregunta:8',
            'Pregunta:9',
            'Pregunta:10',
            'Pregunta:11',
            'Pregunta:12'
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: ''
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'En total desacuerdo',
        data: [<?php

   $prueba="SELECT COUNT(m1) FROM matrizinduccion where m1 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m1)']; }
    ?>,/*separador*/ <?php

   $prueba="SELECT COUNT(m2) FROM matrizinduccion where m2 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m2)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m3) FROM matrizinduccion where m3 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m3)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m4) FROM matrizinduccion where m4 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m4)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m5) FROM matrizinduccion where m5 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m5)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m6) FROM matrizinduccion where m6 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m6)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m7) FROM matrizinduccion where m7 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m7)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m8) FROM matrizinduccion where m8 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m8)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m9) FROM matrizinduccion where m9 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m9)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m10) FROM matrizinduccion where m10 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m10)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m11) FROM matrizinduccion where m11 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m11)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m12) FROM matrizinduccion where m12 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m12)']; }
    ?>]
    }, {
        name: 'En desacuerdo',
        data: [<?php

   $prueba="SELECT COUNT(m1) FROM matrizinduccion where m1 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m1)']; }
    ?>,/*separador*/ <?php

   $prueba="SELECT COUNT(m2) FROM matrizinduccion where m2 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m2)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m3) FROM matrizinduccion where m3 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m3)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m4) FROM matrizinduccion where m4 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m4)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m5) FROM matrizinduccion where m5 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m5)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m6) FROM matrizinduccion where m6 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m6)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m7) FROM matrizinduccion where m7 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m7)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m8) FROM matrizinduccion where m8 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m8)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m9) FROM matrizinduccion where m9 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m9)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m10) FROM matrizinduccion where m10 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m10)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m11) FROM matrizinduccion where m11 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m11)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m12) FROM matrizinduccion where m12 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m12)']; }
    ?>]
    }, {
        name: 'Neutral',
        data: [<?php

   $prueba="SELECT COUNT(m1) FROM matrizinduccion where m1 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m1)']; }
    ?>,/*separador*/ <?php

   $prueba="SELECT COUNT(m2) FROM matrizinduccion where m2 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m2)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m3) FROM matrizinduccion where m3 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m3)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m4) FROM matrizinduccion where m4 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m4)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m5) FROM matrizinduccion where m5 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m5)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m6) FROM matrizinduccion where m6 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m6)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m7) FROM matrizinduccion where m7 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m7)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m8) FROM matrizinduccion where m8 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m8)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m9) FROM matrizinduccion where m9 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m9)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m10) FROM matrizinduccion where m10 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m10)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m11) FROM matrizinduccion where m11 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m11)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m12) FROM matrizinduccion where m12 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m12)']; }
    ?>]
    }, {
        name: 'De acuero',
        data: [<?php

   $prueba="SELECT COUNT(m1) FROM matrizinduccion where m1 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m1)']; }
    ?>,/*separador*/ <?php

   $prueba="SELECT COUNT(m2) FROM matrizinduccion where m2 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m2)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m3) FROM matrizinduccion where m3 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m3)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m4) FROM matrizinduccion where m4 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m4)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m5) FROM matrizinduccion where m5 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m5)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m6) FROM matrizinduccion where m6 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m6)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m7) FROM matrizinduccion where m7 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m7)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m8) FROM matrizinduccion where m8 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m8)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m9) FROM matrizinduccion where m9 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m9)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m10) FROM matrizinduccion where m10 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m10)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m11) FROM matrizinduccion where m11 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m11)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m12) FROM matrizinduccion where m12 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m12)']; }
    ?>]
    }, {
        name: 'En total acuerdo',
        data: [<?php

   $prueba="SELECT COUNT(m1) FROM matrizinduccion where m1 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m1)']; }
    ?>,/*separador*/ <?php

   $prueba="SELECT COUNT(m2) FROM matrizinduccion where m2 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m2)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m3) FROM matrizinduccion where m3 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m3)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m4) FROM matrizinduccion where m4 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m4)']; }
    ?>,/*separador*/  <?php

   $prueba="SELECT COUNT(m5) FROM matrizinduccion where m5 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m5)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m6) FROM matrizinduccion where m6 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m6)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m7) FROM matrizinduccion where m7 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m7)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m8) FROM matrizinduccion where m8 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m8)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m9) FROM matrizinduccion where m9 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m9)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m10) FROM matrizinduccion where m10 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m10)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m11) FROM matrizinduccion where m11 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m11)']; }
    ?>,<?php

   $prueba="SELECT COUNT(m12) FROM matrizinduccion where m12 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['COUNT(m12)']; }
    ?>]
    }]
});




/* ============================
        grafico P3 INDUCCION
============================= */

Highcharts.setOptions({
    colors: Highcharts.map(Highcharts.getOptions().colors, function (color) {
        return {
            radialGradient: {
                cx: 0.5,
                cy: 0.3,
                r: 0.7
            },
            stops: [
                [0, color],
                [1, Highcharts.color(color).brighten(-0.3).get('rgb')] // darken
            ]
        };
    })
    });

    // Build the chart
    Highcharts.chart('P3', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Respuestas Si/No'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    accessibility: {
        point: {
            valueSuffix: '%'
        }
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                connectorColor: 'silver'
            }
        }
    },
    series: [{
        name: 'Porcentaje',
        data: [
            { name: 'Si', y: <?php

   $prueba="SELECT count(P3) FROM induccion where P3 = 'si' AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P3)']; }


    ?> },
            { name: 'NO', y: <?php

   $prueba="SELECT count(P3) FROM induccion where P3 = 'no' AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P3)']; }


    ?> },
        ]
    }]
    });














/* ============================
        grafico P4 SI/NO INDUCCION
============================= */


    // Build the chart
    Highcharts.chart('P4', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Respuestas Si/No'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    accessibility: {
        point: {
            valueSuffix: '%'
        }
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                connectorColor: 'silver'
            }
        }
    },
    series: [{
        name: 'GRAFICO',
        data: [
            { name: 'Si', y: <?php

   $prueba="SELECT count(P4) FROM induccion where P4 = 'si4' AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P4)']; }


    ?> },
            { name: 'NO', y: <?php

   $prueba="SELECT count(P4) FROM induccion where P4 = 'no4' AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P4)']; }


    ?> },
        ]
    }]
    });





/*GRAFICO P5 #####################3
*/
Highcharts.chart('P5', {
    chart: {
        type: 'column'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: [
            'Respuestas',
            'En total desacuerdo',
            'En desacuerdo',
            'Neutral',
            'De acuerdo',
            'Totalmente de acuerdo'
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: ''
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'En total desacuerdo',
        data: [<?php

   $prueba="SELECT count(P5) FROM induccion where P5 = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P5)']; }
    ?>,]
    }, {
        name: 'En desacuerdo',
        data: [<?php

   $prueba="SELECT count(P5) FROM induccion where P5 = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P5)']; }


    ?>]
    }, {
        name: 'Neutral',
        data: [<?php

   $prueba="SELECT count(P5) FROM induccion where P5 = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P5)']; }


    ?>] 
    }, {
        name: 'De acuerdo',
        data: [<?php

   $prueba="SELECT count(P5) FROM induccion where P5 = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P5)']; }


    ?>]
    }, {
        name: 'En total acuerdo',
        data: [<?php

   $prueba="SELECT count(P5) FROM induccion where P5 = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
        $resPrueba=mysqli_query($conexion,$prueba);
    while($data=mysqli_fetch_array($resPrueba)){
    echo $data['count(P5)']; }


    ?>]
    }]
    });


/* ============================
    GRAFICO DE LAS ESTRELLAS
============================= */


Highcharts.chart('estrellas', {
    chart: {
        type: 'column'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: [
            'Respuestas',
            'En total desacuerdo',
            'En desacuerdo',
            'Neutral',
            'De acuerdo',
            'Totalmente de acuerdo'
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: ''
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'Puntaje 0',
        data: [<?php
     $numero="SELECT COUNT(escala) FROM induccion where escala = 0 AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(escala)'];}
     ?> ]

    }, {
        name: 'Puntaje 1',
        data: [<?php
     $numero="SELECT COUNT(escala) FROM induccion where escala = 1 AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(escala)'];}
     ?> ]

    }, {
        name: 'Puntaje 2',
        data: [<?php
     $numero="SELECT COUNT(escala) FROM induccion where escala = 2 AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(escala)'];}
     ?> ]

    }, {
        name: 'Puntaje 3',
        data: [<?php
     $numero="SELECT COUNT(escala) FROM induccion where escala = 3 AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(escala)'];}
     ?> ]

    },{
        name: 'Puntaje 4',
        data: [<?php
     $numero="SELECT COUNT(escala) FROM induccion where escala = 4 AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(escala)'];}
     ?> ]

    },{
        name: 'Puntaje 5',
        data: [<?php
     $numero="SELECT COUNT(escala) FROM induccion where escala = 5 AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(escala)'];}
     ?> ]

    },{
        name: 'Puntaje 6',
        data: [<?php
     $numero="SELECT COUNT(escala) FROM induccion where escala = 6 AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(escala)'];}
     ?> ]

    },{
        name: 'Puntaje 7',
        data: [<?php
     $numero="SELECT COUNT(escala) FROM induccion where escala = 7 AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(escala)'];}
     ?> ]

    },{
        name: 'Puntaje 8',
        data: [<?php
     $numero="SELECT COUNT(escala) FROM induccion where escala = 8 AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(escala)'];}
     ?> ]

    },{
        name: 'Puntaje 9',
        data: [<?php
     $numero="SELECT COUNT(escala) FROM induccion where escala = 9 AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(escala)'];}
     ?> ]

    },{
        name: 'Puntaje 10',
        data: [<?php
     $numero="SELECT COUNT(escala) FROM induccion where escala = 10 AND fecha BETWEEN '$fecha' AND '$fecha2'";
     $nombres=mysqli_query($conexion,$numero);
     while($mos=mysqli_fetch_array($nombres)){
     echo $mos['COUNT(escala)'];}
     ?> ]

    }]
    });



</script>